// There is a bug in angular: https://github.com/angular/angular-cli/pull/8589/files
// Legendary stuff, its webpack plugin pretty much doesn't work with empty TypeScript files in v1.8.3
void 0;
