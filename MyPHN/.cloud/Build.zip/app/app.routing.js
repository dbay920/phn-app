"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("nativescript-angular/router");
var locations_component_1 = require("./locations/locations.component");
var detail_component_1 = require("./locations/detail.component");
var home_component_1 = require("./home/home.component");
var county_component_1 = require("./locations/county.component");
var services_component_1 = require("./services/services.component");
var detail_component_2 = require("./services/detail.component");
var providers_component_1 = require("./providers/providers.component");
var detail_component_3 = require("./providers/detail.component");
var news_component_1 = require("./news/news.component");
var search_component_1 = require("./search/search.component");
var term_component_1 = require("./search/term.component");
var portal_component_1 = require("./portal/portal.component");
var items_component_1 = require("./items.component");
var routes = [
    {
        path: "",
        redirectTo: "/items",
        pathMatch: "full"
    },
    {
        path: "items",
        component: items_component_1.ItemsComponent,
        children: [
            // default route
            { path: "", component: home_component_1.HomeComponent, outlet: 'home' },
            // Location tree
            {
                path: "",
                component: locations_component_1.LocationsComponent,
                outlet: 'locations'
            },
            {
                path: "locations/:id",
                component: county_component_1.CountyComponent,
                outlet: 'locations'
            },
            {
                path: "locations/detail/:id",
                component: detail_component_1.LocationDetailComponent,
                outlet: 'locations'
            },
            // favorites
            { path: 'favorites', component: services_component_1.ServicesComponent },
            // search tree
            { path: '', component: search_component_1.SearchComponent, outlet: 'search' },
            {
                path: 'search/:term',
                component: term_component_1.SearchTermComponent,
                outlet: 'search'
            },
            // services
            {
                path: '',
                component: services_component_1.ServicesComponent,
                outlet: 'services'
            },
            {
                path: 'services/:id',
                component: county_component_1.CountyComponent,
                outlet: 'services'
            },
            // providers
            {
                path: '',
                component: providers_component_1.ProvidersComponent,
                outlet: 'providers'
            },
            {
                path: 'providers/services/:id',
                component: detail_component_2.ServiceDetailComponent,
                outlet: 'providers'
            },
            {
                path: 'providers/:id',
                component: detail_component_3.ProviderDetailComponent,
                outlet: 'providers'
            },
            // portal
            { path: '', component: portal_component_1.PortalComponent, outlet: 'portal' },
            // news
            { path: '', component: news_component_1.NewsComponent, outlet: 'news' },
        ]
    },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        core_1.NgModule({
            imports: [router_1.NativeScriptRouterModule.forRoot(routes)],
            exports: [router_1.NativeScriptRouterModule]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());
exports.AppRoutingModule = AppRoutingModule;
