"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var locations_service_1 = require("../shared/location/locations.service");
var router_1 = require("@angular/router");
var SearchComponent = /** @class */ (function () {
    function SearchComponent(_router, locationsService) {
        this._router = _router;
        this.locationsService = locationsService;
    }
    SearchComponent.prototype.search = function () {
        this._router.navigateByUrl('items/(search:search/' + this.searchTerm + ')');
    };
    SearchComponent.prototype.ngOnInit = function () {
        this.searchTerm = '';
        this.webViewSrc = '';
    };
    SearchComponent = __decorate([
        core_1.Component({
            selector: "ns-items",
            moduleId: module.id,
            templateUrl: "./search.component.html",
        }),
        __metadata("design:paramtypes", [router_1.Router,
            locations_service_1.LocationsService])
    ], SearchComponent);
    return SearchComponent;
}());
exports.SearchComponent = SearchComponent;
