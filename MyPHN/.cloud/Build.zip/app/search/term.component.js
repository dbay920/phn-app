"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var web_view_1 = require("ui/web-view");
var platform_1 = require("platform");
var items_component_1 = require("../items.component");
var SearchTermComponent = (function () {
    function SearchTermComponent(_router, route) {
        this._router = _router;
        this.route = route;
    }
    SearchTermComponent.prototype.isLocation = function (href) {
        return href.indexOf('LocationDetail.aspx?id=') >= 0;
    };
    SearchTermComponent.prototype.isProvider = function (href) {
        return href.indexOf('DoctorBio.aspx?id=') >= 0;
    };
    SearchTermComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.forEach(function (params) {
            _this.searchTerm = params["term"];
        });
        this.webViewSrc = 'https://primary-health.net/Search.aspx?q='
            + this.searchTerm;
    };
    SearchTermComponent.prototype.ngAfterViewInit = function () {
        var _this = this;
        this.ref.first.nativeElement.on(web_view_1.WebView.loadStartedEvent, function (event) {
            if (_this.isLocation(event.url) || _this.isProvider(event.url)) {
                // Stop the loading event
                if (!platform_1.isAndroid) {
                    event.object.ios.stopLoading();
                }
                else {
                    event.object.android.stopLoading();
                }
                // Do something depending on the coordinates in the URL
                if (_this.isLocation(event.url)) {
                    // is location
                    _this._router.navigateByUrl("items/(locations:locations/detail/" +
                        event.url.split('=')[1] + ')');
                    items_component_1.ItemsComponent.setSelectedIndex(4);
                }
                else {
                    // is provider
                    _this._router.navigateByUrl("items/(providers:providers/" +
                        event.url.split('=')[1] + ')');
                    items_component_1.ItemsComponent.setSelectedIndex(6);
                }
            }
        });
    };
    return SearchTermComponent;
}());
__decorate([
    core_1.ViewChildren('ref'),
    __metadata("design:type", core_1.QueryList)
], SearchTermComponent.prototype, "ref", void 0);
SearchTermComponent = __decorate([
    core_1.Component({
        selector: "ns-items",
        moduleId: module.id,
        templateUrl: "./term.component.html",
    }),
    __metadata("design:paramtypes", [router_1.Router,
        router_1.ActivatedRoute])
], SearchTermComponent);
exports.SearchTermComponent = SearchTermComponent;
