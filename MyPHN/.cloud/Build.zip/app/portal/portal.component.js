"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var PortalComponent = /** @class */ (function () {
    function PortalComponent(_router, route) {
        /*this.route.params.forEach((params) => {
            this.searchTerm = params["term"];
        });*/
        this._router = _router;
        this.route = route;
        //this.webViewSrc = 'https://primary-health.net/Search.aspx?q='
        //  + this.searchTerm + '#resInfo-2';
        //console.log(this.webViewSrc)
        this.webViewSrc = 'https://www.medfusion.net/primaryhealth-21154/portal/#/user/login';
    }
    PortalComponent = __decorate([
        core_1.Component({
            selector: "ns-items",
            moduleId: module.id,
            templateUrl: "portal.component.html",
            styleUrls: ["portal.component.css"]
        }),
        __metadata("design:paramtypes", [router_1.Router,
            router_1.ActivatedRoute])
    ], PortalComponent);
    return PortalComponent;
}());
exports.PortalComponent = PortalComponent;
