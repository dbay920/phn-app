"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var locations_service_1 = require("../shared/location/locations.service");
var router_1 = require("@angular/router");
var nativescript_geolocation_1 = require("nativescript-geolocation");
var nativescript_locate_address_1 = require("nativescript-locate-address");
var TNSPhone = require("nativescript-phone");
var LocationDetailComponent = /** @class */ (function () {
    function LocationDetailComponent(route, _router, locationsService, _ngZone) {
        this.route = route;
        this._router = _router;
        this.locationsService = locationsService;
        this._ngZone = _ngZone;
    }
    LocationDetailComponent.prototype.back = function () {
        this._router.navigateByUrl('/items');
    };
    LocationDetailComponent.prototype.myDist = function (x, y) {
        return nativescript_geolocation_1.distance(x, y);
    };
    LocationDetailComponent.prototype.callHome = function () {
        TNSPhone.dial(this.details.getContact(), true);
    };
    LocationDetailComponent.prototype.gotoProvider = function (i) {
        this._router.navigateByUrl("items/(providers:providers/" + this.details.getProviders()[i].getId());
    };
    LocationDetailComponent.prototype.providersTap = function () {
        if (this.providersVisible === 'collapse')
            this.providersVisible = 'visible';
        else
            this.providersVisible = 'collapse';
    };
    LocationDetailComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params
            .forEach(function (params) {
            _this.locationId = params["id"];
        });
        if (!nativescript_geolocation_1.isEnabled()) {
            nativescript_geolocation_1.enableLocationRequest();
            console.log('nonblocking');
        }
        this.locationsService.getLocationDetails(this.locationId).then(function (z) {
            _this.details = z;
            _this.cards = [
                {
                    name: 'About',
                    data: _this.details.getAbout(),
                    icon: 'res://icon_about_location',
                    visible: false
                },
                {
                    name: 'Hours',
                    data: _this.details.getHours(),
                    icon: 'res://icon_hours_location',
                    visible: false
                },
                {
                    name: 'Contact',
                    data: _this.details.getContact(),
                    icon: 'res://icon_phone_location',
                    visible: false
                }
            ];
            _this.providers = [];
            _this.details.getProviders().forEach(function (x) {
                _this.providers.push({
                    name: x.getName(),
                    data: x.getServiceName(),
                    icon: 'res://icon_providers_location',
                    image: x.getImage(),
                    visible: false
                });
            });
            _this.providersTap();
            _this.image = _this.details.getImage();
            _this.address = _this.details.getAddress().replace(', ', '\n');
            _this.name = _this.details.getName();
            var x = _this.details.getGeo();
            nativescript_geolocation_1.getCurrentLocation({
                desiredAccuracy: 3, updateDistance: 10, timeout: 30000
            }).then(function (loc) {
                if (loc) {
                    var metersToMiles = 0.000621371;
                    _this.distance = (_this.myDist(x, loc)
                        * metersToMiles).toFixed(1) + ' mi';
                }
                _this._ngZone.run(function () {
                    // weird fix for arriving from webview
                });
            }, function (e) {
                console.log("Error: " + e.message);
            });
        }, function (error) { return alert("Could not load location details."); });
    };
    LocationDetailComponent.prototype.listViewItemTap = function (i) {
        this.cards[i].visible = !this.cards[i].visible;
    };
    LocationDetailComponent.prototype.navigate = function () {
        var locator = new nativescript_locate_address_1.LocateAddress();
        locator.locate({
            address: this.details.getAddress(),
        }).then(function () {
            console.log("Maps app launched.");
        }, function (error) {
            console.log(error);
        });
    };
    LocationDetailComponent = __decorate([
        core_1.Component({
            selector: "ns-items",
            moduleId: module.id,
            templateUrl: "./detail.component.html",
            styleUrls: ["./detail.component.css", './detail-common.css']
        }),
        __metadata("design:paramtypes", [router_1.ActivatedRoute,
            router_1.Router,
            locations_service_1.LocationsService,
            core_1.NgZone])
    ], LocationDetailComponent);
    return LocationDetailComponent;
}());
exports.LocationDetailComponent = LocationDetailComponent;
