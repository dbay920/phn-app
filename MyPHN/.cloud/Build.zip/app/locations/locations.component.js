"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var locations_service_1 = require("../shared/location/locations.service");
var router_1 = require("@angular/router");
var segmented_bar_1 = require("ui/segmented-bar");
var _ = require("lodash");
var nativescript_geolocation_1 = require("nativescript-geolocation");
var LocationsComponent = /** @class */ (function () {
    function LocationsComponent(route, _router, locationsService) {
        this.route = route;
        this._router = _router;
        this.locationsService = locationsService;
    }
    LocationsComponent.prototype.listViewItemTap = function (i) {
        this.goToLocations(i);
    };
    LocationsComponent.prototype.goToLocations = function (i) {
        switch (this.selectedIndex) {
            case 0:
                this._router.navigateByUrl('items/(locations:locations/' +
                    this.counties[i].getName() + ')');
                break;
            case 1:
                this._router.navigateByUrl('items/(locations:locations/detail/' +
                    (this.sortedDistance[i].getId()) + ')');
                break;
            case 2:
                this._router.navigateByUrl('items/(locations:locations/detail/' +
                    (this.sortedAlphabetically[i].getId()) + ')');
                break;
            default:
                break;
        }
    };
    LocationsComponent.prototype.onSelectedIndexChange = function (event) {
        var segmetedBar = event.object;
        this.selectedIndex = segmetedBar.selectedIndex;
        switch (this.selectedIndex) {
            case 0:
                this.visibility1 = true;
                this.visibility2 = false;
                this.visibility3 = false;
                break;
            case 1:
                this.visibility1 = false;
                this.visibility2 = true;
                this.visibility3 = false;
                break;
            case 2:
                this.visibility1 = false;
                this.visibility2 = false;
                this.visibility3 = true;
                break;
            default:
                break;
        }
    };
    LocationsComponent.prototype.myDist = function (x, y) {
        return nativescript_geolocation_1.distance(x, y);
    };
    LocationsComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (!nativescript_geolocation_1.isEnabled()) {
            nativescript_geolocation_1.enableLocationRequest();
            console.log('nonblocking');
        }
        this.locationsService.getAllLocations().then(function (countyLats) {
            nativescript_geolocation_1.getCurrentLocation({
                desiredAccuracy: 3, updateDistance: 10, timeout: 30000
            }).then(function (loc) {
                if (loc) {
                    _this.sortedDistance = _.sortBy(countyLats, function (feature) {
                        var location = feature.getGeo();
                        var dist = _this.myDist(location, loc);
                        var metersToMiles = 0.000621371;
                        // save distance
                        feature.push((dist * metersToMiles).toFixed(1) + ' mi');
                        return dist;
                    });
                    _this.sortedAlphabetically =
                        _.sortBy(_this.sortedDistance, function (location) {
                            return location.getName();
                        });
                }
            }, function (e) {
                console.log("Error: " + e.message);
            });
        });
        this.i = 0;
        this.myItems = [];
        for (var i = 1; i < 4; i++) {
            var item = new segmented_bar_1.SegmentedBarItem();
            this.myItems.push(item);
        }
        this.myItems[0].title = 'County';
        this.myItems[1].title = 'Distance';
        this.myItems[2].title = 'Alphabetical';
        this.locationsService.getCounties().then(function (x) {
            _this.counties = x;
        }, function (error) { return alert("Could not load location info." + error); });
    };
    LocationsComponent = __decorate([
        core_1.Component({
            selector: "ns-items",
            moduleId: module.id,
            templateUrl: "./locations.component.html",
            styleUrls: ["./locations.component.css", './locations-common.css']
        }),
        __metadata("design:paramtypes", [router_1.ActivatedRoute, router_1.Router, locations_service_1.LocationsService])
    ], LocationsComponent);
    return LocationsComponent;
}());
exports.LocationsComponent = LocationsComponent;
