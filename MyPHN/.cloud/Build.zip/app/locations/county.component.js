"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var locations_service_1 = require("../shared/location/locations.service");
var county_1 = require("../shared/location/county");
var router_1 = require("@angular/router");
var services_component_1 = require("../services/services.component");
var _ = require("lodash");
var CountyComponent = /** @class */ (function () {
    function CountyComponent(route, _router, locationsService) {
        this.route = route;
        this._router = _router;
        this.locationsService = locationsService;
    }
    CountyComponent.prototype.listViewItemTap = function (i) {
        this.goToLocations(i);
    };
    CountyComponent.prototype.back = function () {
        this._router.navigateByUrl('/items');
    };
    CountyComponent.prototype.goToLocations = function (i) {
        this._router.navigateByUrl("items/(locations:locations/detail/" +
            this.locations[i].getId() + ')');
    };
    CountyComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params
            .forEach(function (params) {
            _this.county = county_1.County.buildFromName(params["id"]);
            services_component_1.ServicesComponent.services.forEach(function (service) {
                if (service.getId() == _this.county.getHref())
                    _this.county.service = service.getName();
            });
        });
        this.locationsService.getAllLocations().then(function (x) {
            var path = _this.route.snapshot.url[0].path;
            if (path === 'services') {
                _this.locationsService.getServiceLocationsText(_this.county.getHref()).then(function (y) {
                    _this.locations = _.filter(x, function (loc) {
                        return y.indexOf(loc.getName()) >= 0;
                    });
                });
            }
            else {
                _this.locations = _.filter(x, function (loc) {
                    return loc.getCounty().includes(_this.county.getName());
                });
            }
        }, function (error) { return alert("Could not load locations."); });
    };
    CountyComponent = __decorate([
        core_1.Component({
            selector: "ns-items",
            moduleId: module.id,
            templateUrl: "./county.component.html",
            styleUrls: ["./county.component.css"]
        }),
        __metadata("design:paramtypes", [router_1.ActivatedRoute,
            router_1.Router,
            locations_service_1.LocationsService])
    ], CountyComponent);
    return CountyComponent;
}());
exports.CountyComponent = CountyComponent;
