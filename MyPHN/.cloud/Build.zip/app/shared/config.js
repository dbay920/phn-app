"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Config = (function () {
    function Config() {
    }
    Config.initialize = function () {
    };
    return Config;
}());
Config.messageSenderId = '453784066967'; // used for push notifications
exports.Config = Config;
Config.initialize();
