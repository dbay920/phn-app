"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Config = /** @class */ (function () {
    function Config() {
    }
    Config.initialize = function () {
    };
    Config.messageSenderId = '453784066967'; // used for push notifications
    return Config;
}());
exports.Config = Config;
Config.initialize();
