export class Config {

    static messageSenderId = '453784066967'; // used for push notifications

    static initialize() {

    }
}
Config.initialize();
