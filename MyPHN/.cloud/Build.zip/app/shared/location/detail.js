"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var LocationDetail = /** @class */ (function () {
    function LocationDetail() {
        this.data = [];
    }
    LocationDetail.prototype.setGeo = function (geo) {
        this.geo = geo;
    };
    LocationDetail.prototype.getGeo = function () {
        var geo = this.geo;
        var longitude = geo.match(/long(.*?),/)[1];
        var latitude = geo.match(/lat(.*?)[,<]/) ?
            geo.match(/lat(.*?)[,<]/)[1]
            : geo.split('lat')[1];
        var result = {
            latitude: parseFloat(latitude),
            longitude: parseFloat(longitude)
        };
        return result;
    };
    LocationDetail.prototype.getHref = function () {
        return 'https://primary-health.net/' + this.data[0];
    };
    LocationDetail.prototype.getName = function () {
        return this.data[2];
    };
    LocationDetail.prototype.getPhone = function () {
        return this.data[2];
    };
    LocationDetail.prototype.getAddress = function () {
        return this.about ? this.about[0] : null;
    };
    LocationDetail.prototype.push = function (x) {
        if (x === "")
            return;
        if (x === "Hours") {
            this.about = this.data;
            this.data = [];
            return;
        }
        if (x === "Contact") {
            this.hours = this.data;
            this.data = [];
            return;
        }
        this.data.push(x);
    };
    LocationDetail.prototype.setImage = function (x) {
        if (!this.image)
            this.image = x;
    };
    LocationDetail.prototype.getImage = function () {
        return 'https://primary-health.net/' + this.image;
    };
    LocationDetail.prototype.getHours = function () {
        return this.hours.slice(0, -1).join('\n');
    };
    LocationDetail.prototype.getAbout = function () {
        return this.about[1];
    };
    LocationDetail.prototype.getContact = function () {
        return this.data[0];
    };
    LocationDetail.prototype.setProviders = function (x) {
        this.providers = x;
    };
    LocationDetail.prototype.getProviders = function () {
        return this.providers;
    };
    return LocationDetail;
}());
exports.LocationDetail = LocationDetail;
