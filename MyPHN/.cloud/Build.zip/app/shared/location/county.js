"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var County = (function () {
    function County() {
        this.data = [];
    }
    County.buildFromName = function (name) {
        var obj = new County();
        var county = name.split(' ');
        if (county.length > 1) {
            obj.push('https://primary-health.net/' + county[0] + '.aspx');
        }
        else {
            obj.push(county[0]);
        }
        return obj;
    };
    County.prototype.getHref = function () {
        return this.data[0];
    };
    County.prototype.getName = function () {
        var parts = this.data[0].split('net/');
        if (parts.length > 1) {
            var x = parts[1];
            if (x)
                return x.split('.')[0] + ' County';
        }
        else {
            return this.service;
        }
    };
    County.prototype.push = function (x) {
        this.data.push(x);
    };
    return County;
}());
exports.County = County;
