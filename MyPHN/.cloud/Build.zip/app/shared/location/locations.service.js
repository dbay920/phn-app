"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var fetchModule = require("fetch");
var xmlModule = require("tns-core-modules/xml");
var location_1 = require("./location");
var county_1 = require("./county");
var detail_1 = require("./detail");
var provider_1 = require("../providers/provider");
var currentLocation;
var currentLocations;
var currentCounties;
var currentCounty;
var currentDetail;
var onEventCallback2 = function (event) {
    switch (event.eventType) {
        case xmlModule.ParserEventType.StartElement:
            if (event.elementName !== 'a')
                break;
            currentCounty = new county_1.County();
            currentCounties.push(currentCounty);
            var message = event.eventType + " " + event.elementName;
            if (event.attributes) {
                message += ", Attributes:";
                for (var attributeName in event.attributes) {
                    if (event.attributes.hasOwnProperty(attributeName) && attributeName === 'href') {
                        message += " " + attributeName + "=\"" + event.attributes[attributeName] + "\"";
                        currentCounty.push(event.attributes['href']);
                    }
                }
            }
            //console.log(message);
            break;
        case xmlModule.ParserEventType.EndElement:
            //console.log(event.eventType + " " + event.elementName);
            break;
        case xmlModule.ParserEventType.Text:
            var significantText = event.data.trim();
            if (significantText !== "") {
                //console.log(event.eventType + "=\"" + significantText + "\"");
                //currentCounty.push(significantText);
            }
            break;
    }
};
var onEventCallback3 = function (event) {
    switch (event.eventType) {
        case xmlModule.ParserEventType.StartElement:
            if (event.elementName === 'img') {
                currentDetail.setImage(event.attributes['src']);
            }
            var message = event.eventType + " " + event.elementName;
            if (event.attributes) {
                message += ", Attributes:";
                for (var attributeName in event.attributes) {
                    if (event.attributes.hasOwnProperty(attributeName) && attributeName === 'href') {
                        message += " " + attributeName + "=\"" + event.attributes[attributeName] + "\"";
                    }
                }
            }
            //console.log(message);
            break;
        case xmlModule.ParserEventType.EndElement:
            //            console.log(event.eventType + " " + event.elementName);
            break;
        case xmlModule.ParserEventType.Text:
            var significantText = event.data.trim();
            if (significantText !== "") {
                //   console.log(event.eventType + "=\"" + significantText + "\"");
            }
            currentDetail.push(significantText);
            break;
    }
};
var onErrorCallback = function (error) {
    //console.log("Error: " + error.message);
};
var countyParser = new xmlModule.XmlParser(onEventCallback2, onErrorCallback);
var detailParser = new xmlModule.XmlParser(onEventCallback3, onErrorCallback);
var LocationsService = (function () {
    function LocationsService() {
    }
    LocationsService.prototype.getServiceLocationsText = function (id) {
        return fetchModule.fetch('https://primary-health.net/ServiceDetail.aspx?id=' + id, {
            method: "GET"
        })
            .then(this.handleErrors)
            .then(function (x) {
            return x.text();
        })
            .then(function (x) {
            var token = '<!-- /.etabs -->';
            var result = x.split(token);
            //console.log(result.length)
            return result[1];
        });
    };
    LocationsService.prototype.getAllLocations = function () {
        return fetchModule.fetch('https://primary-health.net/Locations.aspx', {
            method: "GET"
        })
            .then(this.handleErrors)
            .then(function (x) {
            return x.text();
        })
            .then(function (x) {
            var counties = x.split('<article')[1]
                .split('id="Content_CountyList_CountyLabel_').splice(1);
            var results = [];
            counties.forEach(function (county) {
                var locations = county.split(/<ul style="list-style-type: none;">/gm).slice(1);
                var countyName = county.match(/>(.*?)</)[1];
                locations.forEach(function (location) {
                    var result = new location_1.Location();
                    var href = location.match(/href="(.*?)"/)[1];
                    var name = location.match(/itle="(.*?)"/)[1];
                    var phone = location.match(/PhoneLabel_.*?">(.*?)</)[1];
                    var address = location.match(/AddressLabel_.*?">(.*?)</)[1];
                    var image = location.match(/image_.*?">(.*?)</)[1];
                    var geo = location.match(/geoData_.*?">(.*?)</)[1];
                    result.push(href);
                    result.push(name);
                    result.push(phone);
                    result.push(address);
                    result.push(image);
                    result.push(geo);
                    result.push(countyName);
                    results.push(result);
                });
            });
            return results;
        });
    };
    LocationsService.prototype.getLocationDetails = function (id) {
        return fetchModule.fetch('https://primary-health.net/LocationDetail.aspx?id=' + id, {
            method: "GET"
        })
            .then(this.handleErrors)
            .then(function (x) {
            return x.text();
        })
            .then(function (x) {
            var geo = x.match(/<meta name="keywords" content="(.*?)"/)[1];
            var drs = x.split('org/Physician">').slice(1);
            var providers = [];
            currentDetail = new detail_1.LocationDetail();
            drs.forEach(function (dr) {
                var service = dr.match(/<h4><span>(.*)<\/span><\/h4>/)[1];
                var id = dr.match(/\?id=(.*)"/)[1];
                var name = dr.match(/itle="(.*?)" h/)[1];
                var provider = new provider_1.Provider(name);
                provider.setId(id);
                provider.setServiceName(service);
                providers.push(provider);
            });
            currentDetail.setProviders(providers);
            currentDetail.setGeo(geo);
            detailParser.parse('<html><div' +
                x.split('<div class="post format-image"')[1]);
            return currentDetail;
        });
    };
    LocationsService.prototype.getServiceProviders = function (id) {
        return fetchModule.fetch('https://primary-health.net/ServiceDetail.aspx?id=' + id, {
            method: "GET"
        })
            .then(this.handleErrors)
            .then(function (x) {
            return x.text();
        })
            .then(function (x) {
            var token = '<!-- /.etabs -->';
            var result = x.split(token);
            var drs = x.split('org/Physician">').slice(1);
            var providers = [];
            drs.forEach(function (dr) {
                var service = dr.split('span')[6].slice(1, -2);
                var id = dr.match(/\?id=(.*?)"/)[1];
                var name = dr.match(/itle="(.*?)" h/)[1];
                var provider = new provider_1.Provider(name);
                provider.setId(id);
                provider.setServiceName(service);
                providers.push(provider);
            });
            return providers;
        });
    };
    LocationsService.prototype.getCounties = function () {
        return fetchModule.fetch("https://primary-health.net", {
            method: "GET"
        })
            .then(this.handleErrors)
            .then(function (z) {
            return z.text();
        })
            .then(function (y) {
            currentCounties = [];
            //                currentCounties = x.split('Health Centers</a>')[1];
            countyParser.parse('<html>' + y.split('Health Centers</a>')[1]);
            currentCounties.pop();
            currentCounties.pop();
            return currentCounties;
        });
    };
    LocationsService.prototype.handleErrors = function (response) {
        if (!response.ok) {
            throw Error(response.statusText);
        }
        return response;
    };
    return LocationsService;
}());
LocationsService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [])
], LocationsService);
exports.LocationsService = LocationsService;
