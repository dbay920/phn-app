"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Location = (function () {
    function Location() {
        this.data = [];
    }
    // href
    // name
    // phone
    // address
    // image
    // geo
    // county
    // dist
    Location.prototype.getHref = function () {
        return 'https://primary-health.net/' + this.data[0];
    };
    Location.prototype.getId = function () {
        return this.getHref().split('=')[1];
    };
    Location.prototype.getImage = function () {
        if (!this.data[4])
            return '';
        if (this.data[4].indexOf('http') >= 0)
            return this.data[4];
        return 'https://primary-health.net/' + this.data[4];
    };
    Location.prototype.getName = function () {
        return this.data[1];
    };
    Location.prototype.getPhone = function () {
        return this.data[2];
    };
    Location.prototype.getAddress = function () {
        return this.data[3];
    };
    Location.prototype.getGeo = function () {
        var longitude = this.data[5].match(/long(.*?),/)[1];
        var latitude = this.data[5].match(/lat(.*?)[,<]/) ?
            this.data[5].match(/lat(.*?)[,<]/)[1]
            : this.data[5].split('lat')[1];
        var result = {
            latitude: parseFloat(latitude),
            longitude: parseFloat(longitude)
        };
        return result;
    };
    Location.prototype.getCounty = function () {
        return this.data[6];
    };
    Location.prototype.getDist = function () {
        return this.data[7];
    };
    Location.prototype.push = function (x) {
        this.data.push(x);
    };
    return Location;
}());
exports.Location = Location;
