"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var location_1 = require("../location/location");
var Provider = (function () {
    function Provider(name) {
        this.data = [name];
    }
    Provider.prototype.setId = function (x) {
        this.id = x;
    };
    Provider.prototype.getId = function () {
        return this.id;
    };
    Provider.prototype.setServiceName = function (x) {
        this.service = x;
    };
    Provider.prototype.getServiceName = function () {
        return this.service ? this.service : this.data[9];
    };
    Provider.prototype.getLocations = function () {
        var i;
        var result = [];
        for (i = 5; i < this.data.length; i += 7) {
            var currentLocation = new location_1.Location();
            currentLocation.push(this.data[i]);
            currentLocation.push(this.data[i + 1]);
            currentLocation.push(this.data[i + 6]);
            currentLocation.push(this.data[i + 5]);
            result.push(currentLocation);
        }
        return result;
    };
    Provider.prototype.getImage = function () {
        if (this.id)
            return 'https://primary-health.net/images/docimg/' + this.id + '.jpg';
        return 'https://primary-health.net/' + this.data[2];
    };
    Provider.prototype.getDescription = function () {
        return this.data[3];
    };
    Provider.prototype.getName = function () {
        if (this.data.length === 1)
            return this.data[0];
        return this.data[1];
    };
    Provider.prototype.getPhone = function () {
        return this.data[2];
    };
    Provider.prototype.getAddress = function () {
        return this.data[3];
    };
    Provider.prototype.push = function (x) {
        this.data.push(x);
    };
    return Provider;
}());
exports.Provider = Provider;
