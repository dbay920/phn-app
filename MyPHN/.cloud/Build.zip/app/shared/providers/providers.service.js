"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var provider_1 = require("./provider");
var fetchModule = require("fetch");
var xmlModule = require("tns-core-modules/xml");
var currentProvider;
var onEventCallback = function (event) {
    switch (event.eventType) {
        case xmlModule.ParserEventType.StartElement:
            if (event.elementName !== 'img' && event.elementName !== 'a')
                break;
            //currentLocation = new Location();
            //currentLocations.push(currentLocation);
            var message = event.eventType + " " + event.elementName;
            if (event.attributes) {
                message += ", Attributes:";
                for (var attributeName in event.attributes) {
                    if (event.attributes.hasOwnProperty(attributeName) && attributeName === 'src') {
                        message += " " + attributeName + "=\"" + event.attributes[attributeName] + "\"";
                        currentProvider.push(event.attributes['src']);
                    }
                    if (event.attributes.hasOwnProperty(attributeName) && attributeName === 'href') {
                        message += " " + attributeName + "=\"" + event.attributes[attributeName] + "\"";
                        currentProvider.push(event.attributes['href']);
                    }
                }
            }
            break;
        case xmlModule.ParserEventType.EndElement:
            //console.log(event.eventType + " " + event.elementName);
            break;
        case xmlModule.ParserEventType.Text:
            var significantText = event.data.trim();
            if (significantText !== "") {
                currentProvider.push(significantText);
            }
            break;
    }
};
var onErrorCallback = function (error) {
    //console.log("Error: " + error.message);
};
var xmlParser = new xmlModule.XmlParser(onEventCallback, onErrorCallback);
var ProvidersService = (function () {
    function ProvidersService() {
    }
    /*   getServices() {
           return fetchModule.fetch('https://primary-health.net/',
               {
                   method: "GET"
               })
               .then(this.handleErrors)
               .then((x) => {
                   return x.text();
               })
               .then((x) => {
                   currentServices = [];

                   xmlParser.parse(
                       '<html><li' +
                       x.split('<li class="dropdown yamm-fullwidth"')[1]
                   );
                   currentServices.shift()

                   return currentServices;
               });
       }*/
    ProvidersService.prototype.getDetails = function (id) {
        return fetchModule.fetch('https://primary-health.net/DoctorBio.aspx?id=' + id, {
            method: "GET"
        })
            .then(this.handleErrors)
            .then(function (x) {
            var text = x.text();
            return text;
        })
            .then(function (x) {
            currentProvider = new provider_1.Provider('empty');
            xmlParser.parse('<html><div' + x.split('<div class="row"')[2]);
            xmlParser.parse('<html><div' + x.split('<div class="row"')[3]);
            return currentProvider;
        });
    };
    ProvidersService.prototype.handleErrors = function (response) {
        if (!response.ok) {
            throw Error(response.statusText);
        }
        return response;
    };
    return ProvidersService;
}());
ProvidersService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [])
], ProvidersService);
exports.ProvidersService = ProvidersService;
