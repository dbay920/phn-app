"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var fetchModule = require("fetch");
var CensusService = (function () {
    function CensusService() {
    }
    CensusService.prototype.getLocation = function (address) {
        var encoded = address.replace(/ /g, '+').replace(/,/g, '%2C');
        var href = 'https://geocoding.geo.census.gov/geocoder/locations/onelineaddress?address=' + encoded +
            // 4600+Silver+Hill+Rd%2C+Suitland%2C+MD+20746
            '&benchmark=9&format=json';
        return fetchModule.fetch(href, {
            method: "GET"
        })
            .then(this.handleErrors)
            .then(function (x) {
            //console.log(x.text());
            var json = x.json();
            return json;
        }).then(function (raw) {
            var json = raw;
            var cond = (json.result &&
                json.result.addressMatches &&
                json.result.addressMatches.length > 0);
            var result = cond ? {
                latitude: json.result.addressMatches[0].coordinates.y,
                longitude: json.result.addressMatches[0].coordinates.x
            } : {};
            return result;
        });
    };
    CensusService.prototype.handleErrors = function (response) {
        if (!response.ok) {
            throw Error(response.statusText);
        }
        return response;
    };
    return CensusService;
}());
CensusService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [])
], CensusService);
exports.CensusService = CensusService;
