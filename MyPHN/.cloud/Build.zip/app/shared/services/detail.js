"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ServiceDetail = /** @class */ (function () {
    function ServiceDetail() {
        this.data = [];
    }
    ServiceDetail.prototype.getHref = function () {
        return 'https://primary-health.net/' + this.data[0];
    };
    ServiceDetail.prototype.getName = function () {
        return this.data[2];
    };
    ServiceDetail.prototype.getPhone = function () {
        return this.data[2];
    };
    ServiceDetail.prototype.getAddress = function () {
        return this.about ? this.about[0] : null;
    };
    ServiceDetail.prototype.push = function (x) {
        if (x === "")
            return;
        if (x === "Hours") {
            this.about = this.data;
            this.data = [];
            return;
        }
        if (x === "Contact") {
            this.hours = this.data;
            this.data = [];
            return;
        }
        this.data.push(x);
    };
    ServiceDetail.prototype.setImage = function (x) {
        if (!this.image)
            this.image = x;
    };
    ServiceDetail.prototype.getImage = function () {
        return 'https://primary-health.net/' + this.image;
    };
    ServiceDetail.prototype.getHours = function () {
        return this.hours.slice(0, -1).join('\n');
    };
    ServiceDetail.prototype.getAbout = function () {
        return this.about[1];
    };
    ServiceDetail.prototype.getContact = function () {
        return this.data[0];
    };
    ServiceDetail.prototype.getProviders = function () {
        return {};
    };
    return ServiceDetail;
}());
exports.ServiceDetail = ServiceDetail;
