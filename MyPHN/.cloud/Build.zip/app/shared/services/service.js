"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Service = /** @class */ (function () {
    function Service(name) {
        this.data = [name];
    }
    Service.prototype.getHref = function () {
        return this.data[0];
    };
    Service.prototype.getId = function () {
        return this.getHref().split('=')[1];
    };
    Service.prototype.getName = function () {
        return this.data[1];
    };
    Service.prototype.getPhone = function () {
        return this.data[2];
    };
    Service.prototype.getAddress = function () {
        return this.data[3];
    };
    Service.prototype.push = function (x) {
        this.data.push(x);
    };
    return Service;
}());
exports.Service = Service;
