"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var locations_service_1 = require("../shared/location/locations.service");
var router_1 = require("@angular/router");
var nativescript_geolocation_1 = require("nativescript-geolocation");
var nativescript_locate_address_1 = require("nativescript-locate-address");
var items_component_1 = require("../items.component");
var HomeComponent = /** @class */ (function () {
    function HomeComponent(_router, locationsService) {
        this._router = _router;
        this.locationsService = locationsService;
    }
    HomeComponent.prototype.myDist = function (x, y) {
        return nativescript_geolocation_1.distance(x, y);
    };
    HomeComponent.prototype.goToUrl = function (url) {
        this._router.navigateByUrl('');
        items_component_1.ItemsComponent.setSelectedIndex(url);
    };
    HomeComponent.prototype.ngOnInit = function () {
        var _this = this;
        // Loading image to show while detecting location
        this.image = 'res://loadingscreen'; // TODO: change me
        // Cards to show on home screen
        this.cards = [
            {
                name: 'Locations',
                image: 'res://icon_location_home',
                url: 4
            }, {
                name: 'Services',
                image: 'res://icon_service_home',
                url: 5
            }, {
                name: 'Providers',
                image: 'res://icon_provider_home',
                url: 6
            }
        ];
        if (!nativescript_geolocation_1.isEnabled()) {
            nativescript_geolocation_1.enableLocationRequest();
            console.log('nonblocking');
        }
        this.locationsService.getAllLocations().then(function (countyLats) {
            nativescript_geolocation_1.getCurrentLocation({
                desiredAccuracy: 3, updateDistance: 10, timeout: 30000
            }).then(function (loc) {
                if (loc) {
                    var metersToMiles_1 = 0.000621371;
                    var minDist_1 = 8000;
                    var minCounty_1;
                    countyLats.forEach(function (feature) {
                        var location = feature.getGeo();
                        var dist = _this.myDist(location, loc) * metersToMiles_1;
                        if (dist < minDist_1) {
                            minDist_1 = dist;
                            minCounty_1 = feature;
                        }
                    });
                    _this.name = minCounty_1.getName();
                    _this.address = minCounty_1.getAddress().replace(', ', '\n');
                    _this.distance = minDist_1.toFixed(1) + ' mi';
                    _this.image = minCounty_1.getImage();
                }
            }, function (e) {
                // image to show when we cannot determine location
                this.image = 'res://icon_location_home'; // TODO: change me
            });
        });
    };
    HomeComponent.prototype.navigate = function () {
        var _this = this;
        var locator = new nativescript_locate_address_1.LocateAddress();
        locator.available().then(function (avail) {
            if (!avail) {
                alert("maps not available");
            }
            else {
                locator.locate({
                    address: _this.address.replace('\n', '%2C').replace(/ /g, '+').replace(',', '%2C'),
                }).then(function () {
                    console.log("Maps app launched.");
                }, function (error) {
                    console.log(error);
                });
            }
        });
    };
    HomeComponent = __decorate([
        core_1.Component({
            selector: "ns-items",
            moduleId: module.id,
            //change templateUrl to component_test to view test page in emulator
            templateUrl: "./home.component.html",
            styleUrls: ['home.css', 'home-common.css'],
        }),
        __metadata("design:paramtypes", [router_1.Router,
            locations_service_1.LocationsService])
    ], HomeComponent);
    return HomeComponent;
}());
exports.HomeComponent = HomeComponent;
