"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var providers_service_1 = require("../shared/providers/providers.service");
var router_1 = require("@angular/router");
var items_component_1 = require("../items.component");
var TNSPhone = require("nativescript-phone");
var nativescript_locate_address_1 = require("nativescript-locate-address");
var ProviderDetailComponent = (function () {
    function ProviderDetailComponent(route, _router, providersService, _ngZone) {
        this.route = route;
        this._router = _router;
        this.providersService = providersService;
        this._ngZone = _ngZone;
    }
    ProviderDetailComponent.prototype.back = function () {
        this._router.navigateByUrl('/items');
    };
    ProviderDetailComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.forEach(function (params) {
            _this.id = params["id"];
        });
        this.providersService.getDetails(this.id).then(function (x) {
            _this.provider = x;
            _this.name = _this.provider.getName();
            _this.desc = _this.provider.getDescription();
            _this.locations = _this.provider.getLocations();
            _this.image = _this.provider.getImage();
            _this.area = _this.provider.getServiceName();
            _this._ngZone.run(function () {
                // weird fix for arriving from webview
            });
        }, function (error) { return alert("Could not load locations."); });
    };
    ProviderDetailComponent.prototype.goToLocation = function (i) {
        this._router.navigateByUrl("items/(locations:locations/detail/" + i + ')');
        items_component_1.ItemsComponent.setSelectedIndex(4);
    };
    ProviderDetailComponent.prototype.call = function (x) {
        TNSPhone.dial(x, true);
    };
    ProviderDetailComponent.prototype.navigate = function (x) {
        var locator = new nativescript_locate_address_1.LocateAddress();
        locator.available().then(function (avail) {
            if (!avail) {
                alert("maps not available");
            }
            else {
                locator.locate({
                    address: x.replace('\n', '%2C').replace(/ /g, '+').replace(',', '%2C'),
                }).then(function () {
                    console.log("Maps app launched.");
                }, function (error) {
                    console.log(error);
                });
            }
        });
    };
    return ProviderDetailComponent;
}());
ProviderDetailComponent = __decorate([
    core_1.Component({
        selector: "ns-items",
        moduleId: module.id,
        templateUrl: "./detail.component.html",
        styleUrls: ["./detail.component.css", 'detail-common.css']
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute,
        router_1.Router,
        providers_service_1.ProvidersService,
        core_1.NgZone])
], ProviderDetailComponent);
exports.ProviderDetailComponent = ProviderDetailComponent;
