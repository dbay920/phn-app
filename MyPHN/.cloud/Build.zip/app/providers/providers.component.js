"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var services_service_1 = require("../shared/services/services.service");
var router_1 = require("@angular/router");
var ProvidersComponent = (function () {
    function ProvidersComponent(_router, servicesService) {
        this._router = _router;
        this.servicesService = servicesService;
    }
    ProvidersComponent.prototype.goToService = function (i) {
        this._router.navigateByUrl("items/(providers:providers/services/" +
            this.services[i].getId() + '%23tab-2)');
        //        ItemsComponent.setSelectedIndex(5);
    };
    ProvidersComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.servicesService.getServices().then(function (x) {
            _this.services = x;
        });
    };
    ProvidersComponent.prototype.listViewItemTap = function (i) {
        this.goToService(i);
    };
    return ProvidersComponent;
}());
ProvidersComponent = __decorate([
    core_1.Component({
        selector: "ns-items",
        moduleId: module.id,
        templateUrl: "./providers.component.html",
        styleUrls: ['./providers.css', './providers-common.css']
    }),
    __metadata("design:paramtypes", [router_1.Router,
        services_service_1.ServicesService])
], ProvidersComponent);
exports.ProvidersComponent = ProvidersComponent;
