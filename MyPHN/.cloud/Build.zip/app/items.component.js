"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var locations_service_1 = require("./shared/location/locations.service");
var nativescript_angular_1 = require("nativescript-angular");
var page_1 = require("ui/page");
var platform_1 = require("platform");
var utils_1 = require("utils/utils");
var nativescript_screen_orientation_1 = require("nativescript-screen-orientation");
var ItemsComponent = /** @class */ (function () {
    function ItemsComponent(_router, locationsService, routerExtensions, page) {
        this._router = _router;
        this.locationsService = locationsService;
        this.routerExtensions = routerExtensions;
        this.page = page;
        this.canGoBack = null;
        page.on("navigatedTo", function () {
            nativescript_screen_orientation_1.setCurrentOrientation("portrait", function () {
                console.log("portrait orientation");
            });
        });
        page.on("navigatingFrom", function () {
            nativescript_screen_orientation_1.orientationCleanup();
        });
    }
    ItemsComponent_1 = ItemsComponent;
    ItemsComponent.prototype.goBack = function () {
        this.routerExtensions.back();
    };
    ItemsComponent.getSelectedIndex = function () {
        if (!ItemsComponent_1.tabView)
            return -1;
        if (platform_1.isIOS)
            return ItemsComponent_1.tabView.ios.selectedIndex;
        return ItemsComponent_1.tabView.selectedIndex;
    };
    ItemsComponent.setSelectedIndex = function (i) {
        ItemsComponent_1.tabView.selectedIndex = i;
        ItemsComponent_1.showActionBar();
    };
    ItemsComponent.showActionBar = function () {
        if (!ItemsComponent_1.tabView) {
            return;
        }
        var page = ItemsComponent_1.tabView.page;
        if (ItemsComponent_1.navCtrl)
            ItemsComponent_1.navCtrl.navigationBarHidden = true;
        page.actionBarHidden = false;
    };
    ItemsComponent.isMoreTab = function () {
        var index = ItemsComponent_1.getSelectedIndex();
        return platform_1.isAndroid ? false : index === 9223372036854776000;
    };
    // hook for tab change
    ItemsComponent.prototype.onSelectedIndexChanged = function (event) {
        // hook for tab change
        if (ItemsComponent_1.getSelectedIndex() === 0)
            this._router.navigateByUrl('/items');
        ItemsComponent_1.showActionBar();
    };
    ItemsComponent.prototype.ngOnInit = function () {
        var _this = this;
        // handles the hiding of the back button when it is useless
        this._router.events.subscribe(function (val) {
            var switchHash = {
                locations: 4,
                services: 5,
                providers: 6,
                portal: 1,
                news: 2,
                search: 3
            };
            var part = val['url'];
            if (part) {
                part = part.split('(')[1];
                if (part) {
                    part = part.split(':')[0];
                    part = switchHash[part];
                    if (part)
                        ItemsComponent_1.setSelectedIndex(part);
                }
            }
            _this.canGoBack = _this.routerExtensions.canGoBack();
        });
    };
    ItemsComponent.prototype.onLoaded = function (event) {
        if (platform_1.isAndroid) {
            var tabView = event.object._tabLayout.getChildAt(0);
            for (var i = 0; i < tabView.getChildCount(); i++) {
                var tabItem = tabView.getChildAt(i), textView = tabItem.getChildAt(1);
                tabItem.setLayoutParams(new android.widget.LinearLayout
                    .LayoutParams(android.view.ViewGroup.LayoutParams.WRAP_CONTENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT));
                textView.setMaxWidth(utils_1.layout.toDevicePixels(800)); // increase as much you want
                textView.setMaxLines(1);
            }
        }
    };
    ItemsComponent.prototype.ngAfterViewInit = function () {
        // protect from location interruption
        if (this.ref.first) {
            ItemsComponent_1.tabView = this.ref.first.nativeElement;
        }
        if (platform_1.isIOS) {
            ItemsComponent_1.navCtrl =
                ItemsComponent_1.tabView.ios.moreNavigationController;
        }
    };
    ItemsComponent.prototype.search = function () {
        this._router.navigateByUrl('/items');
        ItemsComponent_1.setSelectedIndex(3);
    };
    __decorate([
        core_1.ViewChildren('ref'),
        __metadata("design:type", core_1.QueryList)
    ], ItemsComponent.prototype, "ref", void 0);
    __decorate([
        core_1.ViewChildren('action'),
        __metadata("design:type", core_1.QueryList)
    ], ItemsComponent.prototype, "action", void 0);
    ItemsComponent = ItemsComponent_1 = __decorate([
        core_1.Component({
            selector: "ns-items",
            moduleId: module.id,
            templateUrl: "./items.component.html",
            styleUrls: ['items.component.css', 'items-common.css']
        }),
        __metadata("design:paramtypes", [router_1.Router,
            locations_service_1.LocationsService,
            nativescript_angular_1.RouterExtensions,
            page_1.Page])
    ], ItemsComponent);
    return ItemsComponent;
    var ItemsComponent_1;
}());
exports.ItemsComponent = ItemsComponent;
