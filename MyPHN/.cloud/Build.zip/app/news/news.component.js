"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var items_component_1 = require("../items.component");
var NewsComponent = /** @class */ (function () {
    function NewsComponent(_router) {
        this._router = _router;
    }
    NewsComponent.prototype.goToService = function (i) {
        this._router.navigateByUrl("items/(services:services/"
            + this.services[i].getId() + ')');
        items_component_1.ItemsComponent.setSelectedIndex(5);
    };
    NewsComponent.prototype.ngOnInit = function () {
        this.webViewSrc = 'https://primary-health.net/blog/';
    };
    NewsComponent.prototype.listViewItemTap = function (i) {
        this.goToService(i);
    };
    NewsComponent = __decorate([
        core_1.Component({
            selector: "ns-items",
            moduleId: module.id,
            templateUrl: "./news.component.html",
        }),
        __metadata("design:paramtypes", [router_1.Router])
    ], NewsComponent);
    return NewsComponent;
}());
exports.NewsComponent = NewsComponent;
