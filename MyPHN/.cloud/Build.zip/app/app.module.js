"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var nativescript_module_1 = require("nativescript-angular/nativescript.module");
var app_routing_1 = require("./app.routing");
var app_component_1 = require("./app.component");
var http_1 = require("@angular/http");
var angular_1 = require("nativescript-pro-ui/sidedrawer/angular");
var forms_1 = require("nativescript-angular/forms");
var locations_service_1 = require("./shared/location/locations.service");
var items_component_1 = require("./items.component");
var home_component_1 = require("./home/home.component");
var locations_component_1 = require("./locations/locations.component");
var detail_component_1 = require("./locations/detail.component");
var county_component_1 = require("./locations/county.component");
//import { CensusService } from "./shared/census/census.service"
var services_component_1 = require("./services/services.component");
var detail_component_2 = require("./services/detail.component");
var providers_component_1 = require("./providers/providers.component");
var detail_component_3 = require("./providers/detail.component");
var search_component_1 = require("./search/search.component");
var term_component_1 = require("./search/term.component");
var portal_component_1 = require("./portal/portal.component");
var services_service_1 = require("./shared/services/services.service");
var providers_service_1 = require("./shared/providers/providers.service");
var news_component_1 = require("./news/news.component");
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        bootstrap: [
            app_component_1.AppComponent
        ],
        imports: [
            nativescript_module_1.NativeScriptModule,
            app_routing_1.AppRoutingModule,
            angular_1.NativeScriptUISideDrawerModule,
            forms_1.NativeScriptFormsModule,
            http_1.HttpModule
        ],
        declarations: [
            app_component_1.AppComponent,
            items_component_1.ItemsComponent,
            home_component_1.HomeComponent,
            services_component_1.ServicesComponent,
            detail_component_2.ServiceDetailComponent,
            providers_component_1.ProvidersComponent,
            detail_component_3.ProviderDetailComponent,
            search_component_1.SearchComponent,
            portal_component_1.PortalComponent,
            term_component_1.SearchTermComponent,
            news_component_1.NewsComponent,
            county_component_1.CountyComponent,
            locations_component_1.LocationsComponent,
            detail_component_1.LocationDetailComponent,
        ],
        providers: [
            locations_service_1.LocationsService,
            //        CensusService,
            services_service_1.ServicesService,
            providers_service_1.ProvidersService,
        ],
        schemas: [
            core_1.NO_ERRORS_SCHEMA
        ]
    })
], AppModule);
exports.AppModule = AppModule;
