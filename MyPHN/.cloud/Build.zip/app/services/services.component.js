"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var services_service_1 = require("../shared/services/services.service");
var router_1 = require("@angular/router");
var ServicesComponent = /** @class */ (function () {
    function ServicesComponent(_router, servicesService) {
        this._router = _router;
        this.servicesService = servicesService;
    }
    ServicesComponent_1 = ServicesComponent;
    ServicesComponent.prototype.goToService = function (i) {
        this._router.navigateByUrl("items/(services:services/" +
            ServicesComponent_1.services[i].getId() + ')');
    };
    ServicesComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.servicesService.getServices().then(function (x) {
            ServicesComponent_1.services = x;
            _this.services = x;
        });
    };
    ServicesComponent.prototype.listViewItemTap = function (i) {
        this.goToService(i);
    };
    ServicesComponent = ServicesComponent_1 = __decorate([
        core_1.Component({
            selector: "ns-items",
            moduleId: module.id,
            templateUrl: "./services.component.html",
            styleUrls: ['./services.css', './services-common.css']
        }),
        __metadata("design:paramtypes", [router_1.Router,
            services_service_1.ServicesService])
    ], ServicesComponent);
    return ServicesComponent;
    var ServicesComponent_1;
}());
exports.ServicesComponent = ServicesComponent;
