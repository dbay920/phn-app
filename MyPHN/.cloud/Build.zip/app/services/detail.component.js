"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var locations_service_1 = require("../shared/location/locations.service");
var TNSPhone = require("nativescript-phone");
var ServiceDetailComponent = /** @class */ (function () {
    function ServiceDetailComponent(route, _router, locationsService, _ngZone) {
        this.route = route;
        this._router = _router;
        this.locationsService = locationsService;
        this._ngZone = _ngZone;
    }
    ServiceDetailComponent.prototype.back = function () {
        this._router.navigateByUrl('/items');
    };
    ServiceDetailComponent.prototype.isLocation = function (href) {
        return href.indexOf('LocationDetail.aspx?id=') >= 0;
    };
    ServiceDetailComponent.prototype.isProvider = function (href) {
        return href.indexOf('DoctorBio.aspx?id=') >= 0;
    };
    ServiceDetailComponent.prototype.ngAfterViewInit = function () {
    };
    ServiceDetailComponent.prototype.providersTap = function () {
    };
    ServiceDetailComponent.prototype.gotoProvider = function (i) {
        this._router.navigateByUrl("items/(providers:providers/" + this.providers[i].getId());
    };
    ServiceDetailComponent.prototype.callHome = function (x) {
        TNSPhone.dial(x.getContact(), true);
    };
    ServiceDetailComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.params.forEach(function (params) {
            _this.id = params["id"].split('#')[0];
        });
        this.locationsService.getServiceProviders(this.id).then(function (y) {
            _this.providers = y;
        });
    };
    ServiceDetailComponent = __decorate([
        core_1.Component({
            selector: "ns-items",
            moduleId: module.id,
            templateUrl: "./detail.component.html",
            styleUrls: ["./detail.component.css"]
        }),
        __metadata("design:paramtypes", [router_1.ActivatedRoute,
            router_1.Router,
            locations_service_1.LocationsService,
            core_1.NgZone])
    ], ServiceDetailComponent);
    return ServiceDetailComponent;
}());
exports.ServiceDetailComponent = ServiceDetailComponent;
