## Quickstart

`tns run ios` or `tns run android`


