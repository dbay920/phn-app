module.exports = require("nativescript-plugin-firebase/scripts/entitlements-after-prepare.js");
