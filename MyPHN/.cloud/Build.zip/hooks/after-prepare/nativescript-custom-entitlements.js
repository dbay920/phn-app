module.exports = require("nativescript-custom-entitlements/lib/after-prepare.js");
