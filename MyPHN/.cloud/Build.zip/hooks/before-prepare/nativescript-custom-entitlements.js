module.exports = require("nativescript-custom-entitlements/lib/before-prepare.js");
